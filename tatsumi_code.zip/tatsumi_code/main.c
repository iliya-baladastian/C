#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include<conio.h>
struct student{
  char fname[100];
  char lname[100];
  char father_name[100];
  float grade;
  char class_name[100];
  char code_melli[100];
};
int main()
{
    //my file: classes.txt
    FILE*school=fopen("classes.txt","r");
    //Variables
    int a,size,x;
    char code_melli_v[100];
    char class_name_v[100];
    char std_name_v[100];
    char std_last_name_v[100];
    float grade_v;
    char ans[100];
    char yes[10]="yes";
    char no[10]="no";
    //add Variables
    char first_name_add[1000];
    char last_name_add[1000];
    char father_name_add[1000];
    float grade_add;
    char class_name_add[1000];
    char code_melli_add[1000];
    //char delete
    char vro[100];
    //Admins passwords
    system("cls");
    char password[1000];
    printf("Hello,welcome to your School program!\nenter your password :");

    FILE*pass=fopen("password.txt","r");
    fscanf(pass,"%s",password);
    char input_password[1000];
    scanf("%s",input_password);
    int moghayese=strcmp(input_password,password);
    if(moghayese==0){
    system("cls");
    //Menu
    while(true){
    system("cls");
    printf(" -------------------------------\n");
    printf("| 1_Show all of students        |\n");
    printf("| 2_search a student            |\n");
    printf("| 3_add a student               |\n");
    printf("| 4_Delete a student            |\n");
    printf("| 5_edit a student              |\n");
    printf("| 6_edit your password          |\n");
    printf("| 7_search for class            |\n");
    printf("| 8_Average grades of students  |\n");
    printf(" ------------------------------- \n");
    printf("\n make your choice: ");
    scanf(" %d",&a);
    //INPUT INFO FROM classes.txt
    fscanf(school,"%d",&size);
    struct student d[size];
    for(int b=size-1;b>=0;b--)
        fscanf(school,"%s%s%s%f%s%s",d[b].fname,d[b].lname,d[b].father_name,&d[b].grade,d[b].class_name,d[b].code_melli);
    //SHOW ALL OF STUDENTS
    if(a==1){
        system("cls");

            for(int i=0;i<size;i++)
            {
               printf("-------------------------------------");
               printf("\nfirst name :%s\nlast name :%s\nfather name :%s\ngrade :%f\nclass name :%s\ncode_melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
               printf("-------------------------------------\n");

         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
              }
    //SEARCH A STUDENT BY SOMETHINGS
     else if(a==2)
        {
        //pak
        system("cls");
        printf("1_with student's code melli\n");
        printf("2_with student's name\n");
        printf("3_with student's last name\n");
        printf("4_with student's grade\n");
        printf("\nhow do you want to search ? ");

        scanf(" %d",&x);
    //search with code_melli
     if(x==1){
     system("cls");
     printf("search with code melli :\n");
     scanf("%s",code_melli_v);

     for(int i=0;i<size;i++){
        int res=strcmp(code_melli_v,d[i].code_melli);
        if(res==0){
            printf("-----------------------------------------");
            printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            printf("-----------------------------------------");
        }
     }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
            }
    //search with student's name
    else if(x==2){
        system("cls");
        printf("search with student's name :\n");
        scanf("%s",std_name_v);

        for(int i=0;i<size;i++){
         int res=strcmp(std_name_v,d[i].fname);
         if(res==0){
            printf("-----------------------------------------");
            printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            printf("-----------------------------------------");
        }
    }
          }
     //search with last name
     else if(x==3){
        system("cls");
        printf("search with student's last name :\n");
        scanf("%s",std_last_name_v);

        for(int i=0;i<size;i++){
         int res=strcmp(std_last_name_v,d[i].lname);
         if(res==0){
            printf("-----------------------------------------");
            printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            printf("-----------------------------------------");
        }
    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
          }
     //search with grade
     else if(x==4){
        system("cls");
        printf("search with student's grade :\n");
        scanf("%f",&grade_v);

        for(int i=0;i<size;i++){
                if(grade_v==d[i].grade){
                    printf("-----------------------------------------");
                    printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
                    printf("-----------------------------------------");
                }

         }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
               }
    //birahe
    else printf("\nSorry,try agian\n");
     printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
}
    //ADD A STUDENT TO FILE
    else if(a==3){
            //pak
            system("cls");

           fclose(school);
           FILE*school=fopen("classes.txt","a");
           printf("we are ready to add :\n");
           printf("-----------------------------------------");

           printf("\nfirst name :");
           scanf("%s",first_name_add);

           printf("\nlast name :");
           scanf("%s",last_name_add);

           printf("\nfather name :");
           scanf("%s",father_name_add);

           printf("\ngrade :");
           scanf("%f",&grade_add);

           printf("\nclass name :");
           scanf("%s",class_name_add);

           printf("\ncode melli :");
           scanf("%s",code_melli_add);

           //for sure
           system("cls");
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");

           printf("\n-----------------------------------------\n");
           scanf("%s",ans);
           //add our input to our file
           int mosavi=strcmp(ans,yes);
           if(mosavi==0){
           int jk=1;
           int jdo=size+jk;
           fclose(school);
           FILE*school=fopen("classes.txt","w");
           fprintf(school,"%d",jdo);
           for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
           fprintf(school,"\n%s %s %s %f %s %s",first_name_add,last_name_add,father_name_add,grade_add,class_name_add,code_melli_add);
           fclose(school);
           system("cls");
           printf("                                                     -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
       else{
               system("cls");
               printf("OK,finish\n");
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
           }
                       }
        //DELET A STUDENT
    else if(a==4){
           char sr[100];
           system("cls");
                printf("enter a name :");
                scanf("%s",sr);
         //for search
         int index;
        for(int i=0;i<size;i++){
         int res=strcmp(sr,d[i].fname);
         if(res==0){
            index=i;
            printf("-----------------------------------------");
            printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            printf("-----------------------------------------");
        }
    }

         //paian search
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n-----------------------------------------\n");
           scanf("%s",ans);
           int mosavi=strcmp(ans,yes);
           if(mosavi==0){


           for(int i=index;i<size;i++){
                d[i]=d[i+1];
                }

                size=size-1;
                fclose(school);
                FILE*school=fopen("classes.txt","w");
                fprintf(school,"%d",size);
                for(int i=0;i<size;i++){
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
                                       }
               fclose(school);
           system("cls");
           printf("                                                     -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

           printf("\nany key to continue/q for exit\n");
           char ch;
           ch=getch();
           //if(ch=='q')break;

                       }
}
    //edit a student
    else if(a==5){
        system("cls");
        char name[100];
        printf("Enter a std name :");
        scanf("%s",name);
        system("cls");
        for(int i=0;i<size;i++){
         int res=strcmp(name,d[i].fname);
         if(res==0){
            printf("first name :%s \nlast name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);

        }
    }
        printf("\nwhat do you want to edit ?");
        printf("\n---------------------");
        printf("\n1 for A first name   |");
        printf("\n2 for A last name    |");
        printf("\n3 for A father name  |");
        printf("\n4 for A grade        |");
        printf("\n5 for A class name   |");
        printf("\n6 for A code malli   |");
        printf("\n---------------------");

        int c;
        printf("\nmake your choice :");
        scanf("%d",&c);

        //shrote
        if(c==1){
             system("cls");
             printf("enter your new name :");
             char new_name[100];
             scanf("%s",new_name);
             for(int i=0;i<size;i++){
             int cox=strcmp(name,d[i].fname);
         if(cox==0){
            strcpy(d[i].fname,new_name);
        }

    }
           printf("\nname will be :%s\n",new_name);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
    else if(c==2){
                 system("cls");
                 printf("enter your new  last name :");
                 char new_l_name[100];
                 scanf("%s",new_l_name);
                 for(int i=0;i<size;i++){
                     int cox=strcmp(name,d[i].fname);
                 if(cox==0){
                     strcpy(d[i].lname,new_l_name);
                 }
                }
           printf("\nlast name will be :%s\n",new_l_name);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
     else if(c==3){
                 system("cls");
                 printf("enter your new father name :");
                 char new_f_name[100];
                 scanf("%s",new_f_name);
                 for(int i=0;i<size;i++){
                     int cox=strcmp(name,d[i].fname);
                 if(cox==0){
                     strcpy(d[i].father_name,new_f_name);
                 }

    }
           printf("\nfather name will be :%s\n",new_f_name);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
     else if(c==4){
                 system("cls");
                 printf("enter your new grade :");
                 float new_g_name;
                 scanf("%f",&new_g_name);
                 for(int i=0;i<size;i++){
                     int cox=strcmp(name,d[i].fname);
                 if(cox==0){
                     d[i].grade=new_g_name;
                  }
    }
           printf("\ngrade will be :%f\n",new_g_name);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
    else if(c==5){
                 system("cls");
                 printf("enter your new class name :");
                 char new_c_name[100];
                 scanf("%s",new_c_name);
                 for(int i=0;i<size;i++){
                     int cox=strcmp(name,d[i].fname);
                     if(cox==0){
                           strcpy(d[i].class_name,new_c_name);
                 }
        }
           printf("\nclass name will be :%s\n",new_c_name);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
     else if(c==6){
                 system("cls");
                 printf("enter your new code malli :");
                 char new_code[100];
                 scanf("%s",new_code);
                 for(int i=0;i<size;i++){
                     int cox=strcmp(name,d[i].fname);
                 if(cox==0){
                     strcpy(d[i].code_melli,new_code);
                 }

    }
           printf("\ncode melli will be :%s\n",new_code);
           printf("-----------------------------------------");
           printf("\nAre you sure ?\nyes or no ?");
           printf("\n---------------------------------------\n");
           char bazam[10];
           scanf("%s",bazam);
           int bro=strcmp(bazam,yes);
    if(bro==0){
    fclose(school);
    FILE*school=fopen("classes.txt","w");
    fprintf(school,"%d",size);
     for(int i=0;i<size;i++)
            {
               fprintf(school,"\n%s %s %s %f %s %s",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            }
    fclose(school);
           system("cls");
           printf("\n                                                    -----------------\n");
           printf("                                                    |                 |\n");
           printf("                                                    |    WE DONE IT   |\n");
           printf("                                                    |                 |\n");
           printf("                                                     -----------------\n");
           printf("\n");
           printf("\n");
           printf("\n");

    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
    if(c>6){
        system("cls");
        printf("sorry,try again");
    }
    }

    //edit user password
    else if(a==6){
        system("cls");
        printf("enter your new password :");
        fclose(pass);
        char new_password[100];
        scanf("%s",new_password);
        system("cls");
           printf("-----------------------------------------");
           printf("\nAre you sure to save it ?\nyes or no ?");
           printf("\n-----------------------------------------\n");
           char answer[100];
           scanf("%s",answer);
           int moghayese_num2=strcmp(answer,yes);
           if(moghayese_num2==0){
                FILE*pass=fopen("password.txt","w");
                fprintf(pass,"%s",new_password);
                system("cls");
                printf("                                                           ----------\n");
                printf("                                                          | we done it|\n");
                printf("                                                           -----------\n");
           }
           else {
            system("cls");
            printf("\nOK\n");
           }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
    //search for class
    else if(a==7){
        system("cls");
        printf("search with class name :\n");
        scanf("%s",class_name_v);

         for(int i=0;i<size;i++){
         int res=strcmp(class_name_v,d[i].class_name);
         if(res==0){
            printf("-----------------------------------------");
            printf("\nfirst name :%s \n last name :%s \nfather_name:%s \ngrade :%f \nclass name :%s \ncode melli :%s\n",d[i].fname,d[i].lname,d[i].father_name,d[i].grade,d[i].class_name,d[i].code_melli);
            printf("-----------------------------------------");
        }
    }
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
                  }
    //mayangin
    else if(a==8){

        float sum=0;
        for(int i=0;i<size;i++){
        for(d[i].grade;i<size;i++){
            sum=sum+d[i].grade;
        }

}
         sum=sum/size;
         printf("%f",sum);
         printf("\nany key to continue/q for exit\n");
         char ch;
         ch=getch();
         //if(ch=='q')break;
    }
    //akhar khat
    else{
        printf("\n SORRY, try again!!\n");
    }
        system("pause");

    }
    }

     else {
        printf("\nSorry,your password is wrong,try again!!\n");
     }

    return 0;
}


